<?php
/**
 * @package OPTOMETRY
 *
 * APPLICATION-WIDE CONFIGURATION SETTINGS
 *
 * This file contains application-wide configuration settings.  The settings
 * here will be the same regardless of the machine on which the app is running.
 *
 * This configuration should be added to version control.
 *
 * No settings should be added to this file that would need to be changed
 * on a per-machine basic (ie local, staging or production).  Any
 * machine-specific settings should be added to _machine_config.php
 */

/**
 * APPLICATION ROOT DIRECTORY
 * If the application doesn't detect this correctly then it can be set explicitly
 */
if (!GlobalConfig::$APP_ROOT) GlobalConfig::$APP_ROOT = realpath("./");

/**
 * check is needed to ensure asp_tags is not enabled
 */
if (ini_get('asp_tags')) 
	die('<h3>Server Configuration Problem: asp_tags is enabled, but is not compatible with Savant.</h3>'
	. '<p>You can disable asp_tags in .htaccess, php.ini or generate your app with another template engine such as Smarty.</p>');

/**
 * INCLUDE PATH
 * Adjust the include path as necessary so PHP can locate required libraries
 */
set_include_path(
		GlobalConfig::$APP_ROOT . '/libs/' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/../phreeze/libs' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/vendor/phreeze/phreeze/libs/' . PATH_SEPARATOR .
		get_include_path()
);

/**
 * COMPOSER AUTOLOADER
 * Uncomment if Composer is being used to manage dependencies
 */
// $loader = require 'vendor/autoload.php';
// $loader->setUseIncludePath(true);

/**
 * SESSION CLASSES
 * Any classes that will be stored in the session can be added here
 * and will be pre-loaded on every page
 */
require_once "App/ExampleUser.php";

/**
 * RENDER ENGINE
 * You can use any template system that implements
 * IRenderEngine for the view layer.  Phreeze provides pre-built
 * implementations for Smarty, Savant and plain PHP.
 */
require_once 'verysimple/Phreeze/SavantRenderEngine.php';
GlobalConfig::$TEMPLATE_ENGINE = 'SavantRenderEngine';
GlobalConfig::$TEMPLATE_PATH = GlobalConfig::$APP_ROOT . '/templates/';

/**
 * ROUTE MAP
 * The route map connects URLs to Controller+Method and additionally maps the
 * wildcards to a named parameter so that they are accessible inside the
 * Controller without having to parse the URL for parameters such as IDs
 */
GlobalConfig::$ROUTE_MAP = array(

	// default controller when no route specified
	'GET:' => array('route' => 'Default.Home'),
		
	// example authentication routes
	'GET:loginform' => array('route' => 'SecureExample.LoginForm'),
	'POST:login' => array('route' => 'SecureExample.Login'),
	'GET:secureuser' => array('route' => 'SecureExample.UserPage'),
	'GET:secureadmin' => array('route' => 'SecureExample.AdminPage'),
	'GET:logout' => array('route' => 'SecureExample.Logout'),
		
	// Appointment
	'GET:appointments' => array('route' => 'Appointment.ListView'),
	'GET:appointment/(:any)' => array('route' => 'Appointment.SingleView', 'params' => array('locationid' => 1)),
	'GET:api/appointments' => array('route' => 'Appointment.Query'),
	'POST:api/appointment' => array('route' => 'Appointment.Create'),
	'GET:api/appointment/(:any)' => array('route' => 'Appointment.Read', 'params' => array('locationid' => 2)),
	'PUT:api/appointment/(:any)' => array('route' => 'Appointment.Update', 'params' => array('locationid' => 2)),
	'DELETE:api/appointment/(:any)' => array('route' => 'Appointment.Delete', 'params' => array('locationid' => 2)),
		
	// Contactlens
	'GET:contactlenses' => array('route' => 'Contactlens.ListView'),
	'GET:contactlens/(:num)' => array('route' => 'Contactlens.SingleView', 'params' => array('clensid' => 1)),
	'GET:api/contactlenses' => array('route' => 'Contactlens.Query'),
	'POST:api/contactlens' => array('route' => 'Contactlens.Create'),
	'GET:api/contactlens/(:num)' => array('route' => 'Contactlens.Read', 'params' => array('clensid' => 2)),
	'PUT:api/contactlens/(:num)' => array('route' => 'Contactlens.Update', 'params' => array('clensid' => 2)),
	'DELETE:api/contactlens/(:num)' => array('route' => 'Contactlens.Delete', 'params' => array('clensid' => 2)),
		
	// Eye
	'GET:eyes' => array('route' => 'Eye.ListView'),
	'GET:eye/(:any)' => array('route' => 'Eye.SingleView', 'params' => array('patientid' => 1)),
	'GET:api/eyes' => array('route' => 'Eye.Query'),
	'POST:api/eye' => array('route' => 'Eye.Create'),
	'GET:api/eye/(:any)' => array('route' => 'Eye.Read', 'params' => array('patientid' => 2)),
	'PUT:api/eye/(:any)' => array('route' => 'Eye.Update', 'params' => array('patientid' => 2)),
	'DELETE:api/eye/(:any)' => array('route' => 'Eye.Delete', 'params' => array('patientid' => 2)),
		
	// Glasseslens
	'GET:glasseslenses' => array('route' => 'Glasseslens.ListView'),
	'GET:glasseslens/(:num)' => array('route' => 'Glasseslens.SingleView', 'params' => array('glensid' => 1)),
	'GET:api/glasseslenses' => array('route' => 'Glasseslens.Query'),
	'POST:api/glasseslens' => array('route' => 'Glasseslens.Create'),
	'GET:api/glasseslens/(:num)' => array('route' => 'Glasseslens.Read', 'params' => array('glensid' => 2)),
	'PUT:api/glasseslens/(:num)' => array('route' => 'Glasseslens.Update', 'params' => array('glensid' => 2)),
	'DELETE:api/glasseslens/(:num)' => array('route' => 'Glasseslens.Delete', 'params' => array('glensid' => 2)),
		
	// Manufacturer
	'GET:manufacturers' => array('route' => 'Manufacturer.ListView'),
	'GET:manufacturer/(:num)' => array('route' => 'Manufacturer.SingleView', 'params' => array('manufid' => 1)),
	'GET:api/manufacturers' => array('route' => 'Manufacturer.Query'),
	'POST:api/manufacturer' => array('route' => 'Manufacturer.Create'),
	'GET:api/manufacturer/(:num)' => array('route' => 'Manufacturer.Read', 'params' => array('manufid' => 2)),
	'PUT:api/manufacturer/(:num)' => array('route' => 'Manufacturer.Update', 'params' => array('manufid' => 2)),
	'DELETE:api/manufacturer/(:num)' => array('route' => 'Manufacturer.Delete', 'params' => array('manufid' => 2)),
		
	// Office
	'GET:offices' => array('route' => 'Office.ListView'),
	'GET:office/(:num)' => array('route' => 'Office.SingleView', 'params' => array('officeid' => 1)),
	'GET:api/offices' => array('route' => 'Office.Query'),
	'POST:api/office' => array('route' => 'Office.Create'),
	'GET:api/office/(:num)' => array('route' => 'Office.Read', 'params' => array('officeid' => 2)),
	'PUT:api/office/(:num)' => array('route' => 'Office.Update', 'params' => array('officeid' => 2)),
	'DELETE:api/office/(:num)' => array('route' => 'Office.Delete', 'params' => array('officeid' => 2)),
		
	// Optometrist
	'GET:optometrists' => array('route' => 'Optometrist.ListView'),
	'GET:optometrist/(:num)' => array('route' => 'Optometrist.SingleView', 'params' => array('employeeid' => 1)),
	'GET:api/optometrists' => array('route' => 'Optometrist.Query'),
	'POST:api/optometrist' => array('route' => 'Optometrist.Create'),
	'GET:api/optometrist/(:num)' => array('route' => 'Optometrist.Read', 'params' => array('employeeid' => 2)),
	'PUT:api/optometrist/(:num)' => array('route' => 'Optometrist.Update', 'params' => array('employeeid' => 2)),
	'DELETE:api/optometrist/(:num)' => array('route' => 'Optometrist.Delete', 'params' => array('employeeid' => 2)),
		
	// Order
	'GET:orders' => array('route' => 'Order.ListView'),
	'GET:order/(:num)' => array('route' => 'Order.SingleView', 'params' => array('orderid' => 1)),
	'GET:api/orders' => array('route' => 'Order.Query'),
	'POST:api/order' => array('route' => 'Order.Create'),
	'GET:api/order/(:num)' => array('route' => 'Order.Read', 'params' => array('orderid' => 2)),
	'PUT:api/order/(:num)' => array('route' => 'Order.Update', 'params' => array('orderid' => 2)),
	'DELETE:api/order/(:num)' => array('route' => 'Order.Delete', 'params' => array('orderid' => 2)),
		
	// Patient
	'GET:patients' => array('route' => 'Patient.ListView'),
	'GET:patient/(:num)' => array('route' => 'Patient.SingleView', 'params' => array('patientid' => 1)),
	'GET:api/patients' => array('route' => 'Patient.Query'),
	'POST:api/patient' => array('route' => 'Patient.Create'),
	'GET:api/patient/(:num)' => array('route' => 'Patient.Read', 'params' => array('patientid' => 2)),
	'PUT:api/patient/(:num)' => array('route' => 'Patient.Update', 'params' => array('patientid' => 2)),
	'DELETE:api/patient/(:num)' => array('route' => 'Patient.Delete', 'params' => array('patientid' => 2)),
		
	// Prescription
	'GET:prescriptions' => array('route' => 'Prescription.ListView'),
	'GET:prescription/(:num)' => array('route' => 'Prescription.SingleView', 'params' => array('prescriptionid' => 1)),
	'GET:api/prescriptions' => array('route' => 'Prescription.Query'),
	'POST:api/prescription' => array('route' => 'Prescription.Create'),
	'GET:api/prescription/(:num)' => array('route' => 'Prescription.Read', 'params' => array('prescriptionid' => 2)),
	'PUT:api/prescription/(:num)' => array('route' => 'Prescription.Update', 'params' => array('prescriptionid' => 2)),
	'DELETE:api/prescription/(:num)' => array('route' => 'Prescription.Delete', 'params' => array('prescriptionid' => 2)),

	// catch any broken API urls
	'GET:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'PUT:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'POST:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'DELETE:api/(:any)' => array('route' => 'Default.ErrorApi404')
);

/**
 * FETCHING STRATEGY
 * You may uncomment any of the lines below to specify always eager fetching.
 * Alternatively, you can copy/paste to a specific page for one-time eager fetching
 * If you paste into a controller method, replace $G_PHREEZER with $this->Phreezer
 */
?>