<?php
/** @package    Optometry::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * OfficeCriteria allows custom querying for the Office object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package Optometry::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class OfficeCriteriaDAO extends Criteria
{

	public $Officeid_Equals;
	public $Officeid_NotEquals;
	public $Officeid_IsLike;
	public $Officeid_IsNotLike;
	public $Officeid_BeginsWith;
	public $Officeid_EndsWith;
	public $Officeid_GreaterThan;
	public $Officeid_GreaterThanOrEqual;
	public $Officeid_LessThan;
	public $Officeid_LessThanOrEqual;
	public $Officeid_In;
	public $Officeid_IsNotEmpty;
	public $Officeid_IsEmpty;
	public $Officeid_BitwiseOr;
	public $Officeid_BitwiseAnd;
	public $Name_Equals;
	public $Name_NotEquals;
	public $Name_IsLike;
	public $Name_IsNotLike;
	public $Name_BeginsWith;
	public $Name_EndsWith;
	public $Name_GreaterThan;
	public $Name_GreaterThanOrEqual;
	public $Name_LessThan;
	public $Name_LessThanOrEqual;
	public $Name_In;
	public $Name_IsNotEmpty;
	public $Name_IsEmpty;
	public $Name_BitwiseOr;
	public $Name_BitwiseAnd;
	public $Address_Equals;
	public $Address_NotEquals;
	public $Address_IsLike;
	public $Address_IsNotLike;
	public $Address_BeginsWith;
	public $Address_EndsWith;
	public $Address_GreaterThan;
	public $Address_GreaterThanOrEqual;
	public $Address_LessThan;
	public $Address_LessThanOrEqual;
	public $Address_In;
	public $Address_IsNotEmpty;
	public $Address_IsEmpty;
	public $Address_BitwiseOr;
	public $Address_BitwiseAnd;
	public $Phone_Equals;
	public $Phone_NotEquals;
	public $Phone_IsLike;
	public $Phone_IsNotLike;
	public $Phone_BeginsWith;
	public $Phone_EndsWith;
	public $Phone_GreaterThan;
	public $Phone_GreaterThanOrEqual;
	public $Phone_LessThan;
	public $Phone_LessThanOrEqual;
	public $Phone_In;
	public $Phone_IsNotEmpty;
	public $Phone_IsEmpty;
	public $Phone_BitwiseOr;
	public $Phone_BitwiseAnd;

}

?>