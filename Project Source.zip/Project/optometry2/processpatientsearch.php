<!DOCTYPE html>
<?php
$name=$_POST['name'];
$patientid=$_POST['patientid'];
?>
<html lang="en">
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-Frame-Options" content="deny">
		<base href="http://192.168.185.143/optometry2/" />
		<title>OPTOMETRY | Appointments</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta name="description" content="OPTOMETRY" />
		<meta name="author" content="phreeze builder | phreeze.com" />

		<!-- Le styles -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" />
		<link href="styles/style.css" rel="stylesheet" />
		<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link href="bootstrap/css/font-awesome.min.css" rel="stylesheet" />
		<!--[if IE 7]>
		<link rel="stylesheet" href="bootstrap/css/font-awesome-ie7.min.css">
		<![endif]-->
		<link href="bootstrap/css/datepicker.css" rel="stylesheet" />
		<link href="bootstrap/css/timepicker.css" rel="stylesheet" />
		<link href="bootstrap/css/bootstrap-combobox.css" rel="stylesheet" />
		
		<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
			<script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!-- Le fav and touch icons -->
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114-precomposed.png" />
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72-precomposed.png" />
		<link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon-57-precomposed.png" />

		<script type="text/javascript" src="scripts/libs/LAB.min.js"></script>
		<script type="text/javascript">
			$LAB.script("//code.jquery.com/jquery-1.8.2.min.js").wait()
				.script("bootstrap/js/bootstrap.min.js")
				.script("bootstrap/js/bootstrap-datepicker.js")
				.script("bootstrap/js/bootstrap-timepicker.js")
				.script("bootstrap/js/bootstrap-combobox.js")
				.script("scripts/libs/underscore-min.js").wait()
				.script("scripts/libs/underscore.date.min.js")
				.script("scripts/libs/backbone-min.js")
				.script("scripts/app.js")
				.script("scripts/model.js").wait()
				.script("scripts/view.js").wait()
		</script>

	</head>
<body>

			<div class="navbar navbar-inverse navbar-fixed-top">
				<div class="navbar-inner">
					<div class="container">
						<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</a>
						<a class="brand" href="./">OPTOMETRY</a>
						<div class="nav-collapse collapse">
							<ul class="nav">
								<li ><a href="./appointments">Appointments</a></li>
								<li ><a href="./contactlenses">Contactlenses</a></li>
								<li ><a href="./eyes">Eyes</a></li>
								<li ><a href="./glasseslenses">Glasseslenses</a></li>
							</ul>
							<ul class="nav">
								<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">More <b class="caret"></b></a>
								<ul class="dropdown-menu">
								<li ><a href="./manufacturers">Manufacturers</a></li>
								<li ><a href="./offices">Offices</a></li>
								<li ><a href="./optometrists">Optometrists</a></li>
								<li ><a href="./orders">Orders</a></li>
								<li ><a href="./patients">Patients</a></li>
								<li ><a href="./prescriptions">Prescriptions</a></li>
								</ul>
								</li>
							</ul>
							<ul class="nav pull-right">
								<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-lock"></i> Login <i class="caret"></i></a>
								<ul class="dropdown-menu">
									<li><a href="./loginform">Login</a></li>
									<li class="divider"></li>
									<li><a href="./secureuser">Example User Page <i class="icon-lock"></i></a></li>
									<li><a href="./secureadmin">Example Admin Page <i class="icon-lock"></i></a></li>
								</ul>
								</li>
							</ul>
						</div><!--/.nav-collapse -->
					</div>
				</div>
			</div>
<script type="text/javascript">
	$LAB.script("scripts/app/appointments.js").wait(function(){
		$(document).ready(function(){
			page.init();
		});
		
		// hack for IE9 which may respond inconsistently with document.ready
		setTimeout(function(){
			if (!page.isInitialized) page.init();
		},1000);
	});
</script>

<body>








    <section id="page-breadcrumb">
        <div class="vertical-center sun">
             <div class="container">
                <div class="row">
                    <div class="action">
                        <div class="col-sm-12">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </section>
    <!--/#action-->

    <section id="portfolio">
        <div class="container">
            <div class="row">

                    
                
<?php

if($patientid==NULL)
{$patientid="";}
if($name==NULL)
{$name="";}

$query= "SELECT * FROM patient WHERE (patient.patientid=\"$patientid\" OR patient.name=\"$name\") LIMIT 0,1;";



$cxn=mysqli_connect('localhost', 'root', 'haleydennis', 'optometry')
     or  die ("Connection to DB Server Failed.");
		//echo $query;
	 $result=mysqli_query($cxn, $query)
		or die("This query died. Too bad.".mysqli_error($cxn));

?>
<h2>Patient Information</h2>
<table border="1">
<form action = "http://192.168.185.143/sites/template/multicolor/processpatientsearch.php" method = "post">
<?php
echo "
	<tr>
		<td>Patient ID</td>
		<td>Name</td>
		<td>Phone 1</td>
		<td>Phone 2</td>
		<td>Address</td>
		<td>City</td>
		<td>State</td>
	</tr>
		<tr>
			<td><input type='text' name='patientid'></td>
			<td><input type='text' name='name'></td>
			<td>-</td><td>-</td><td>-</td><td>-</td><td>-</td>
		</tr>
	";

$row = mysqli_fetch_assoc($result);

	extract($row);
	echo "
		<tr>
			<td>$patientid</td>
			<td>$name</td>
			<td>$phone1</td>
			<td>$phone2</td>
			<td>$housenumber $street</td>
			<td>$city</td>
			<td>$state</td>
		</tr>


</table>
<input type=\"submit\" value=\"Search\">
</form>
<BR><BR>
<div>
<table border=\"1\">
";
$query2="SELECT * FROM eye, prescription WHERE eye.patientid=$patientid AND eye.side='L' AND eye.prescriptionid=prescription.prescriptionid;";
if($patientid==NULL)
{die;}
$result2=mysqli_query($cxn, $query2)
		or die("This query died. Too bad.".mysqli_error($cxn));
$row = mysqli_fetch_assoc($result2);
extract($row);

if ($glensid!=NULL)
{
	$query3="SELECT * FROM eye, prescription, glasseslens WHERE eye.patientid=$patientid AND eye.side='L' AND eye.prescriptionid=prescription.prescriptionid AND prescription.glensid=glasseslens.glensid;";
	$result3=mysqli_query($cxn, $query3)
		or die("This query died. Too bad.".mysqli_error($cxn));
	$row = mysqli_fetch_assoc($result3);
	extract($row);
	echo"
		<tr>
			<td><h3>Left Eye</h3>
		</tr>
		<tr>
			<td>Color: $color</td>
		</tr>
		<tr>
			<td>Glasses ID</td>
			<td>Manufacturer</td>
			<td>Sphere</td>
			<td>Base Curve</td>
		</tr>
		<tr>
		<td>Glasses Prescription ID: $glensid</td><td>$manufid</td><td>$sphere</td><td>$basecurve</td>
		</tr>";
}
elseif ($clensid!=NULL)
{
	$query3="SELECT * FROM eye, prescription, contactlens WHERE eye.patientid=$patientid AND eye.side='L' AND eye.prescriptionid=prescription.prescriptionid AND prescription.clensid=contactlens.clensid;";
	$result3=mysqli_query($cxn, $query3)
		or die("This query died. Too bad.".mysqli_error($cxn));
	$row = mysqli_fetch_assoc($result3);
	extract($row);

	echo"
	<tr>
		<td><h3>Left Eye</h3>
	</tr>
	<tr>
		<td>Color: $color</td>
	</tr>
	<tr>
		<td>Contact Lens ID</td>
		<td>Name</td>
		<td>Sphere</td>
		<td>Base Curve</td>
		<td>Diameter</td>
	</tr>
	<tr>
	<td>Contact Prescription ID: $glensid</td><td>$name</td><td>$sphere</td><td>$basecurve</td><td>$diameter</td>
	</tr>
	";
}
else
{
	echo"
	<tr>
		<td><h3>Left Eye</h3>
	</tr>
	<tr>
		<td>Color: $color</td>
	</tr>
	<tr><td>No Prescription Found</td></tr>";
}

echo "</table>
<table border=\"1\">";

//Right eye

$query2="SELECT * FROM eye, prescription WHERE eye.patientid=$patientid AND eye.side='R' AND eye.prescriptionid=prescription.prescriptionid;";
$result2=mysqli_query($cxn, $query2)
		or die("This query died. Too bad.".mysqli_error($cxn));
$row = mysqli_fetch_assoc($result2);
if ($glensid!=NULL)
{
	$query3="SELECT * FROM eye, prescription WHERE eye.patientid=$patientid AND eye.side='R' AND eye.prescriptionid=prescription.prescriptionid;";
	$result3=mysqli_query($cxn, $query3)
		or die("This query died. Too bad.".mysqli_error($cxn));
	$row = mysqli_fetch_assoc($result3);
	extract($row);
	echo"
		<tr>
			<td><h3>Right Eye</h3>
		</tr>
		<tr>
			<td>Color: $color</td>
		</tr>
		<tr>
			<td>Glasses ID</td>
			<td>Manufacturer</td>
			<td>Sphere</td>
			<td>Base Curve</td>
		</tr>
		<tr>
		<td>Glasses Prescription ID: $glensid</td><td>$manufid</td><td>$sphere</td><td>$basecurve</td>
		</tr>";
}
elseif ($clensid!=NULL)
{
	$query3="SELECT * FROM eye, prescription WHERE eye.patientid=$patientid AND eye.side='R' AND eye.prescriptionid=prescription.prescriptionid;";
	$result3=mysqli_query($cxn, $query3)
		or die("This query died. Too bad.".mysqli_error($cxn));
	$row = mysqli_fetch_assoc($result3);
	extract($row);

	echo"
	<tr>
		<td><h3>Right Eye</h3>
	</tr>
	<tr>
		<td>Color: $color</td>
	</tr>
	<tr>
		<td>Contact Lens ID</td>
		<td>Name</td>
		<td>Sphere</td>
		<td>Base Curve</td>
		<td>Diameter</td>
	</tr>
	<tr>
	<td>Contact Prescription ID: $glensid</td><td>$name</td><td>$sphere</td><td>$basecurve</td><td>$diameter</td>
	</tr>
	";
}
else
{
	echo"
	<tr>
		<td><h3>Right Eye</h3><td>
	</tr>
	<tr>
		<td>Color: $color</td>
	</tr>
	<tr><td>No Prescription Found</td></tr>";
}

echo "</table>";
?>
</div>

</form>
</table>
                </div>

            </div>
        </div>
    </section>
    <!--/#portfolio-->


  
    <!--/#footer-->


    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.isotope.min.js"></script>
    <script type="text/javascript" src="js/lightbox.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>    
</body>
</html>
